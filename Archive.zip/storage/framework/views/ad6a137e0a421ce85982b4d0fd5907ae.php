<?php $__env->startSection('title', 'DAP Trust Donation Amount Particulars'); ?>
<?php $__env->startSection('heading', 'DAP Trust Donation Amount Particulars'); ?>
<?php $__env->startSection('subheading', 'Donations · donation income by year & mode of receipt'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Donations Received', 'value' => $money($donationIncome), 'hint' => 'All donation income', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Receipts Issued', 'value' => number_format($donationCount), 'hint' => 'Recorded donations'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Financial Years', 'value' => number_format($byYear->count()), 'hint' => 'Of donation records'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 px-5 py-4">
            <h2 class="font-semibold text-slate-900">Donations by Financial Year</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Financial Year</th>
                        <th class="px-5 py-3 text-right font-medium">Donations</th>
                        <th class="px-5 py-3 text-right font-medium">Amount Received</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $byYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 font-medium text-slate-800"><?php echo e($row->financial_year); ?></td>
                            <td class="px-5 py-3 text-right text-slate-600"><?php echo e(number_format($row->count)); ?></td>
                            <td class="px-5 py-3 text-right font-semibold text-emerald-600"><?php echo e($money($row->total)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="px-5 py-6 text-center text-slate-500">No donation particulars recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if($byMode->isNotEmpty()): ?>
        <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="font-semibold text-slate-900">Donations by Mode of Receipt</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = $byMode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e($row->mode_of_receipt); ?></span>
                        <span class="font-semibold text-emerald-600"><?php echo e($money($row->total)); ?> <span class="text-xs font-normal text-slate-400">(<?php echo e(number_format($row->count)); ?>)</span></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transparency.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/donation-particulars.blade.php ENDPATH**/ ?>