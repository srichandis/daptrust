<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('heading', $title); ?>
<?php $__env->startSection('subheading', $subtitle); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Total (' . $series[0]['fy'] . ' — ' . end($series)['fy'] . ')', 'value' => $money($total), 'hint' => 'Sum across all financial years', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Best Year', 'value' => $money($max), 'hint' => 'Highest single financial year'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
            <h2 class="text-lg font-semibold text-slate-900">Year-by-Year (<?php echo e($series[0]['fy']); ?> — <?php echo e(end($series)['fy']); ?>)</h2>
            <span class="text-xs font-medium text-emerald-600">● Live update</span>
        </div>
        <?php echo $__env->make('transparency.partials.trend-chart', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <p class="mt-4 text-xs text-slate-400">
            Hover over a bar to see the exact amount for that financial year. Figures update automatically as entries are recorded.
        </p>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Figures by Financial Year</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Financial Year</th>
                        <th class="px-5 py-3 text-right font-medium">Amount</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = array_reverse($series); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 font-medium text-slate-800"><?php echo e($row['fy']); ?></td>
                            <td class="px-5 py-3 text-right font-semibold <?php echo e($row['value'] > 0 ? 'text-emerald-600' : 'text-slate-400'); ?>"><?php echo e($money($row['value'])); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/trends.blade.php ENDPATH**/ ?>