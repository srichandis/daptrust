<?php $__env->startSection('title', 'Merge Similar Names'); ?>
<?php $__env->startSection('heading', 'Merge Similar Names'); ?>
<?php $__env->startSection('subheading', 'Find and merge entries with similar donor/particulars names'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <form method="GET" action="<?php echo e(route('admin.merge.index')); ?>" class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Entry type</label>
                <select name="entry_type" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="">All types</option>
                    <?php $__currentLoopData = $entryTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if(($filters['entry_type'] ?? '') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Account</label>
                <select name="account_id" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="">All accounts</option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>" <?php if(($filters['account_id'] ?? '') == $account->id): echo 'selected'; endif; ?>><?php echo e($account->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Similarity threshold</label>
                <select name="threshold" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="0.6" <?php if(($filters['threshold'] ?? '0.75') == '0.6'): echo 'selected'; endif; ?>>Loose (60%)</option>
                    <option value="0.7" <?php if(($filters['threshold'] ?? '0.75') == '0.7'): echo 'selected'; endif; ?>>Medium (70%)</option>
                    <option value="0.75" <?php if(($filters['threshold'] ?? '0.75') == '0.75'): echo 'selected'; endif; ?>>Default (75%)</option>
                    <option value="0.85" <?php if(($filters['threshold'] ?? '0.75') == '0.85'): echo 'selected'; endif; ?>>Strict (85%)</option>
                    <option value="0.95" <?php if(($filters['threshold'] ?? '0.75') == '0.95'): echo 'selected'; endif; ?>>Exact (95%)</option>
                </select>
            </div>
            <div class="flex items-end gap-2">
                <button type="submit" class="rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-900">Find Groups</button>
                <a href="<?php echo e(route('admin.merge.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Reset</a>
            </div>
        </form>
    </div>

    
    <div class="mb-5 flex items-center gap-4">
        <div class="rounded-lg border border-slate-200 bg-white px-4 py-2 shadow-sm">
            <span class="text-sm text-slate-500">Groups found:</span>
            <span class="ml-1 font-semibold text-slate-800"><?php echo e($groups->count()); ?></span>
        </div>
        <div class="rounded-lg border border-slate-200 bg-white px-4 py-2 shadow-sm">
            <span class="text-sm text-slate-500">Total entries to merge:</span>
            <span class="ml-1 font-semibold text-slate-800"><?php echo e($groups->sum('count')); ?></span>
        </div>
    </div>

    
    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupIdx => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="mb-4 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm" x-data="{ open: false, merged: false }">
            
            <button type="button" @click="open = !open"
                    class="flex w-full items-center justify-between px-5 py-4 text-left transition hover:bg-slate-50">
                <div class="flex items-center gap-4">
                    <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-sm font-bold text-emerald-700">
                        <?php echo e($group['count']); ?>

                    </span>
                    <div>
                        <p class="font-semibold text-slate-800"><?php echo e($group['canonical']); ?></p>
                        <p class="text-sm text-slate-500">
                            <?php echo e($group['count']); ?> entries · Total ₹<?php echo e(number_format($group['total'], 2)); ?>

                            <?php if(isset($group['unique_names']) && $group['unique_names']->count() > 1): ?>
                                <span class="ml-2 text-xs text-amber-600">
                                    (<?php echo e($group['unique_names']->count()); ?> variations: <?php echo e($group['unique_names']->take(4)->implode(', ')); ?><?php echo e($group['unique_names']->count() > 4 ? '…' : ''); ?>)
                                </span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <svg class="h-5 w-5 shrink-0 text-slate-400 transition-transform duration-200" :class="open ? 'rotate-180' : ''"
                     fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/>
                </svg>
            </button>

            
            <div x-show="open" x-cloak style="display: none;">
                <div class="border-t border-slate-100 px-5 py-4">
                    
                    <form method="POST" action="<?php echo e(route('admin.merge.submit')); ?>" class="mb-4"
                          x-on:submit="if(!confirm('Merge <?php echo e($group['count']); ?> entries under this name?')) return false;">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-wrap items-end gap-3">
                            <div class="flex-1">
                                <label class="mb-1 block text-xs font-medium text-slate-500">Canonical name (all entries will be renamed to this)</label>
                                <input type="text" name="canonical_name" value="<?php echo e($group['canonical']); ?>"
                                       class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none"
                                       required>
                            </div>
                            <?php $__currentLoopData = $group['entries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="entry_ids[]" value="<?php echo e($entry->id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit"
                                    class="rounded-lg bg-emerald-600 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700">
                                Merge <?php echo e($group['count']); ?> entries
                            </button>
                        </div>
                    </form>

                    
                    <div class="overflow-x-auto rounded-lg border border-slate-100">
                        <table class="w-full text-left text-sm">
                            <thead>
                                <tr class="border-b border-slate-100 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                                    <th class="px-4 py-2 font-semibold">Date</th>
                                    <th class="px-4 py-2 font-semibold">Type</th>
                                    <th class="px-4 py-2 font-semibold">Account</th>
                                    <th class="px-4 py-2 font-semibold">Particulars</th>
                                    <th class="px-4 py-2 font-semibold">Donor Name</th>
                                    <th class="px-4 py-2 text-right font-semibold">Amount</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50">
                                <?php $__currentLoopData = $group['entries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-slate-50">
                                        <td class="whitespace-nowrap px-4 py-2 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                                        <td class="px-4 py-2">
                                            <span class="rounded-full px-2 py-0.5 text-xs font-medium
                                                <?php echo e($entry->is_income ? 'bg-emerald-100 text-emerald-700' : ($entry->is_expense ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600')); ?>">
                                                <?php echo e($entry->label); ?>

                                            </span>
                                        </td>
                                        <td class="whitespace-nowrap px-4 py-2 text-slate-600"><?php echo e($entry->account?->name ?? '—'); ?></td>
                                        <td class="max-w-xs truncate px-4 py-2 text-slate-500"><?php echo e($entry->particulars ?: '—'); ?></td>
                                        <td class="max-w-xs truncate px-4 py-2 font-medium text-slate-800"><?php echo e($entry->donor_name ?: '—'); ?></td>
                                        <td class="whitespace-nowrap px-4 py-2 text-right font-semibold <?php echo e($entry->is_income ? 'text-emerald-600' : 'text-red-600'); ?>">
                                            ₹<?php echo e(number_format($entry->amount, 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="rounded-xl border border-slate-200 bg-white px-6 py-12 text-center shadow-sm">
            <svg class="mx-auto h-12 w-12 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
            <p class="mt-3 text-slate-500">No similar name groups found with the current filters.</p>
            <p class="mt-1 text-sm text-slate-400">Try lowering the similarity threshold or removing filters.</p>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/merge/index.blade.php ENDPATH**/ ?>