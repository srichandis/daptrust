<?php $__env->startSection('title', 'DAP Trust IT Return Details'); ?>
<?php $__env->startSection('heading', 'DAP Trust IT Return Details'); ?>
<?php $__env->startSection('subheading', 'Investments & compliance · live register'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Refunds Received', 'value' => $money($refunds), 'hint' => 'IT return refunds', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Tax Paid', 'value' => $money($paid), 'hint' => 'IT paid entries', 'color' => 'text-red-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="font-semibold text-slate-900">IT Return Register</h2>
            <span class="text-xs font-medium text-emerald-600">● Live</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Date</th>
                        <th class="px-5 py-3 font-medium">Type</th>
                        <th class="px-5 py-3 font-medium">Account</th>
                        <th class="px-5 py-3 font-medium">Particulars</th>
                        <th class="px-5 py-3 text-right font-medium">Amount</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                            <td class="px-5 py-3">
                                <span class="rounded-full px-2 py-0.5 text-xs font-medium <?php echo e($entry->entry_type === \App\Models\Entry::TYPE_IT_RETURN ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'); ?>">
                                    <?php echo e($entry->label); ?>

                                </span>
                            </td>
                            <td class="px-5 py-3 text-slate-600"><?php echo e($entry->account?->name ?? '—'); ?></td>
                            <td class="max-w-xs truncate px-5 py-3 text-slate-500"><?php echo e($entry->particulars ?: '—'); ?></td>
                            <td class="px-5 py-3 text-right font-semibold <?php echo e($entry->entry_type === \App\Models\Entry::TYPE_IT_RETURN ? 'text-emerald-600' : 'text-red-600'); ?>">
                                <?php echo e(($entry->entry_type === \App\Models\Entry::TYPE_IT_RETURN ? '+' : '−') . $money($entry->amount)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-5 py-6 text-center text-slate-500">No IT return entries recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transparency.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/it-return.blade.php ENDPATH**/ ?>