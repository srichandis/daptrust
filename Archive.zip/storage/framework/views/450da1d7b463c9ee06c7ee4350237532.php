<p class="mb-4 text-sm text-slate-500">Entries dated 31 March within the selected period.</p>
<?php if($entries->isEmpty()): ?>
    <p class="text-sm text-slate-500">No 31 March entries in the selected period.</p>
<?php else: ?>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
            <tr class="text-left text-xs uppercase tracking-wide text-slate-500">
                <th class="pb-2 pr-4">Date</th>
                <th class="pb-2 pr-4">Type</th>
                <th class="pb-2 pr-4">Account</th>
                <th class="pb-2 pr-4 text-right">Amount</th>
                <th class="pb-2">Notes</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t border-slate-100">
                    <td class="whitespace-nowrap py-2 pr-4"><?php echo e($entry->entry_date?->format('d-m-Y')); ?></td>
                    <td class="py-2 pr-4"><?php echo e($entry->label); ?></td>
                    <td class="py-2 pr-4"><?php echo e($entry->account?->name ?: '—'); ?></td>
                    <td class="whitespace-nowrap py-2 pr-4 text-right font-medium <?php echo e($entry->is_income ? 'text-emerald-600' : 'text-rose-600'); ?>">
                        ₹<?php echo e(indian_number_format($entry->amount, 2)); ?>

                    </td>
                    <td class="py-2"><?php echo e($entry->notes ?: '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/reports/partials/year-end.blade.php ENDPATH**/ ?>