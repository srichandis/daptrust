<?php $__env->startSection('title', 'DAP Trust Financial Report'); ?>
<?php $__env->startSection('heading', 'DAP Trust Financial Report'); ?>
<?php $__env->startSection('subheading', 'Live update · every entry recorded on this portal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'INCOME', 'value' => $money($incomeTotal), 'hint' => 'Donations + Interest + IT Return', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'EXPENSE', 'value' => $money($expenseTotal), 'hint' => 'Donations given + Charges', 'color' => 'text-red-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'SAVINGS', 'value' => $money($savings), 'hint' => 'Income − Expenses', 'color' => $savings >= 0 ? 'text-emerald-600' : 'text-red-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'EXP + SAV', 'value' => $money($incomeTotal), 'hint' => 'Should equal INCOME', 'color' => 'text-slate-900'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-2">
        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Income by Type</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = \App\Models\Entry::GROUPS['Income']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e(\App\Models\Entry::labelFor($type)); ?></span>
                        <span class="font-semibold text-emerald-600"><?php echo e($money($incomeByType[$type] ?? 0)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Expenses by Type</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = \App\Models\Entry::GROUPS['Expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e(\App\Models\Entry::labelFor($type)); ?></span>
                        <span class="font-semibold text-red-600"><?php echo e($money($expenseByType[$type] ?? 0)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Latest Entries</h2>
            <span class="text-xs font-medium text-emerald-600">● Live</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Date</th>
                        <th class="px-5 py-3 font-medium">Type</th>
                        <th class="px-5 py-3 font-medium">Account</th>
                        <th class="px-5 py-3 font-medium">Particulars</th>
                        <th class="px-5 py-3 text-right font-medium">Amount</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $latestEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                            <td class="px-5 py-3">
                                <span class="rounded-full px-2 py-0.5 text-xs font-medium <?php echo e($entry->is_income ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'); ?>">
                                    <?php echo e($entry->label); ?>

                                </span>
                            </td>
                            <td class="px-5 py-3 text-slate-600"><?php echo e($entry->account?->name ?? '—'); ?></td>
                            <td class="max-w-xs truncate px-5 py-3 text-slate-500"><?php echo e($entry->particulars ?: $entry->donor_name ?: '—'); ?></td>
                            <td class="px-5 py-3 text-right font-semibold <?php echo e($entry->is_income ? 'text-emerald-600' : 'text-red-600'); ?>">
                                <?php echo e(($entry->is_income ? '+' : '−') . $money($entry->amount)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-5 py-6 text-center text-slate-500">No entries yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/financial-report.blade.php ENDPATH**/ ?>