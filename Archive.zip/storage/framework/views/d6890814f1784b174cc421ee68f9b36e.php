<?php $__env->startSection('title', 'DAP Trust Bank Particulars'); ?>
<?php $__env->startSection('heading', 'DAP Trust Bank Particulars'); ?>
<?php $__env->startSection('subheading', 'Investments & compliance · accounts held by the trust'); ?>

<?php $__env->startSection('content'); ?>
    <p class="mb-5 max-w-2xl text-sm leading-relaxed text-slate-600">
        Bank accounts and cash holdings of the trust. Account numbers and IFSC codes are masked for security.
    </p>

    <div class="grid gap-5 sm:grid-cols-2">
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <div class="flex items-center justify-between">
                    <div class="flex h-11 w-11 items-center justify-center rounded-xl <?php echo e($account->type === 'cash' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'); ?> text-lg font-bold">
                        <?php echo e($account->type === 'cash' ? '₹' : strtoupper(substr($account->name, 0, 1))); ?>

                    </div>
                    <span class="rounded-full px-2.5 py-1 text-xs font-medium capitalize <?php echo e($account->type === 'cash' ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'); ?>"><?php echo e($account->type); ?></span>
                </div>
                <h3 class="mt-4 font-semibold text-slate-900"><?php echo e($account->name); ?></h3>
                <p class="text-xs text-slate-400"><?php echo e($account->bank_name ?: '—'); ?></p>

                <dl class="mt-4 space-y-2 text-sm">
                    <div class="flex items-center justify-between">
                        <dt class="text-slate-500">Balance</dt>
                        <dd class="font-semibold text-slate-900"><?php echo e($money($account->balance())); ?></dd>
                    </div>
                    <div class="flex items-center justify-between">
                        <dt class="text-slate-500">Branch</dt>
                        <dd class="text-slate-700"><?php echo e($account->branch ?: '—'); ?></dd>
                    </div>
                    <div class="flex items-center justify-between">
                        <dt class="text-slate-500">Account No.</dt>
                        <dd class="font-mono text-slate-700"><?php echo e($account->account_number ? '••••'.substr($account->account_number, -4) : '—'); ?></dd>
                    </div>
                    <div class="flex items-center justify-between">
                        <dt class="text-slate-500">IFSC</dt>
                        <dd class="font-mono text-slate-700"><?php echo e($account->ifsc ?: '—'); ?></dd>
                    </div>
                    <?php if($account->investment_type !== 'none'): ?>
                        <div class="flex items-center justify-between">
                            <dt class="text-slate-500">Investments</dt>
                            <dd class="font-medium text-indigo-600"><?php echo e(strtoupper($account->investment_type)); ?></dd>
                        </div>
                    <?php endif; ?>
                </dl>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/bank-particulars.blade.php ENDPATH**/ ?>