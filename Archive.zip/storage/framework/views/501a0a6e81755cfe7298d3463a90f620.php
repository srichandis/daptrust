<?php $__env->startSection('title', 'DAP Trust OPS Donation'); ?>
<?php $__env->startSection('heading', 'DAP Trust OPS Donation'); ?>
<?php $__env->startSection('subheading', 'Investments · donations to OPS Saiva Peravai'); ?>

<?php $__env->startSection('content'); ?>
    <p class="mb-5 max-w-2xl text-sm leading-relaxed text-slate-600">
        Donations made by the trust to OPS Saiva Peravai and its centres — recorded and published live.
    </p>

    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Total OPS Donations', 'value' => $money($total), 'hint' => 'All OPS donation entries', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'OPS Centres', 'value' => number_format($byPlace->count()), 'hint' => 'Distinct centres supported'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-2">
        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">By Centre</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $byPlace->sortDesc(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place => $totalPlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e($place); ?></span>
                        <span class="font-semibold text-emerald-600"><?php echo e($money($totalPlace)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-slate-500">No OPS donations recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Recent OPS Donations</h2>
                <span class="text-xs font-medium text-emerald-600">● Live</span>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $entries->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <div>
                            <p class="text-slate-600"><?php echo e($entry->entry_date?->format('d M Y')); ?> · <?php echo e($entry->particulars); ?></p>
                            <p class="text-xs text-slate-400"><?php echo e($entry->account?->name ?? '—'); ?></p>
                        </div>
                        <span class="font-semibold text-emerald-600"><?php echo e($money($entry->amount)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-slate-500">No OPS donations recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/ops.blade.php ENDPATH**/ ?>