<?php $__env->startSection('title', 'DAP Trust ' . $label . ' Details'); ?>
<?php $__env->startSection('heading', 'DAP Trust ' . $label . ' Details'); ?>
<?php $__env->startSection('subheading', 'Investments · live register'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Invested', 'value' => $money($invested), 'hint' => 'Total ' . $label . ' invested', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Interest Earned', 'value' => $money($interestTotal), 'hint' => 'All ' . $label . ' interest', 'color' => 'text-emerald-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Matured', 'value' => $money($matured), 'hint' => 'Principal returned on maturity'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Investments</h2>
            <span class="text-xs font-medium text-emerald-600">● Live</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Date</th>
                        <th class="px-5 py-3 font-medium">Account</th>
                        <th class="px-5 py-3 font-medium">Particulars</th>
                        <th class="px-5 py-3 text-right font-medium">Amount</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                            <td class="px-5 py-3 text-slate-600"><?php echo e($entry->account?->name ?? '—'); ?></td>
                            <td class="max-w-xs truncate px-5 py-3 text-slate-500"><?php echo e($entry->particulars ?: '—'); ?></td>
                            <td class="px-5 py-3 text-right font-semibold text-emerald-600"><?php echo e($money($entry->amount)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="px-5 py-6 text-center text-slate-500">No <?php echo e(strtolower($label)); ?> investments recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-2">
        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Interest</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e($entry->entry_date?->format('d M Y')); ?> · <?php echo e($entry->account?->name ?? '—'); ?></span>
                        <span class="font-semibold text-emerald-600"><?php echo e($money($entry->amount)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-slate-500">No interest entries recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Maturities</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $maturities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <div>
                            <p class="text-slate-600"><?php echo e($entry->entry_date?->format('d M Y')); ?> · <?php echo e($entry->account?->name ?? '—'); ?></p>
                            <?php if($entry->interest_amount): ?>
                                <p class="text-xs text-slate-400">Interest <?php echo e($money($entry->interest_amount)); ?></p>
                            <?php endif; ?>
                        </div>
                        <span class="font-semibold text-slate-800"><?php echo e($money($entry->amount)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="px-5 py-6 text-sm text-slate-500">No maturities recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/investment.blade.php ENDPATH**/ ?>