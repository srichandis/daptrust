<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full bg-slate-100">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> — <?php echo e(\App\Http\Controllers\TransparencyController::TRUST_NAME); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="h-full bg-slate-100 font-sans text-slate-700 antialiased">
<div x-data="{ open: false }" class="min-h-full lg:flex">

    
    <aside class="hidden bg-[#0b2447] text-slate-300 lg:flex lg:w-72 lg:shrink-0 lg:flex-col lg:min-h-screen" :class="open ? '!flex' : ''">
        <div class="flex h-16 items-center justify-between border-b border-white/10 px-5">
            <a href="<?php echo e(route('transparency.index')); ?>" class="flex items-center gap-2.5">
                <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500 text-lg font-bold text-white">D</div>
                <div class="leading-tight">
                    <p class="text-sm font-bold tracking-wide text-white">DAP TRUST</p>
                    <p class="text-[10px] uppercase tracking-widest text-slate-400">Financial &amp; Transparency</p>
                </div>
            </a>
        </div>

        <nav class="flex-1 overflow-y-auto px-3 py-4">
            <?php $__currentLoopData = \App\Http\Controllers\TransparencyController::MENU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="mt-4 mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-widest text-slate-500 first:mt-0"><?php echo e($group); ?></p>
                <ul class="space-y-0.5">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$page, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('transparency.'.$page)); ?>"
                               class="flex items-start gap-2 rounded-lg px-3 py-2 text-[13px] leading-snug transition <?php echo e(request()->routeIs('transparency.'.$page) ? 'bg-emerald-500/15 font-semibold text-emerald-300' : 'text-slate-300 hover:bg-white/5 hover:text-white'); ?>">
                                <span class="mt-1.5 h-1 w-1 shrink-0 rounded-full <?php echo e(request()->routeIs('transparency.'.$page) ? 'bg-emerald-400' : 'bg-slate-600'); ?>"></span>
                                <?php echo e($label); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <div class="hidden border-t border-white/10 px-5 py-4 text-xs text-slate-400 lg:block">
            <p class="font-semibold text-slate-300"><?php echo e(\App\Http\Controllers\TransparencyController::TRUST_NAME); ?></p>
            <p class="mt-0.5">Established: <?php echo e(\App\Http\Controllers\TransparencyController::ESTABLISHED); ?></p>
        </div>
    </aside>

    
    <div class="min-w-0 flex-1">
        <header class="sticky top-0 z-10 border-b border-slate-200 bg-white/90 backdrop-blur">
            <div class="flex items-center justify-between gap-4 px-4 py-3 sm:px-6">
                <div class="flex min-w-0 items-center gap-3">
                    <button @click="open = !open" class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 lg:hidden" aria-label="Menu">
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8"><path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
                    </button>
                    <div class="min-w-0">
                        <h1 class="truncate text-lg font-semibold text-slate-900"><?php echo $__env->yieldContent('heading', 'Financial & Transparency Dashboard'); ?></h1>
                        <p class="hidden truncate text-xs text-slate-500 sm:block"><?php echo $__env->yieldContent('subheading', \App\Http\Controllers\TransparencyController::TRUST_NAME.' — live, open financial records'); ?></p>
                    </div>
                </div>
                <a href="<?php echo e(route('home')); ?>" class="shrink-0 rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-slate-50">
                    ← Back to Home
                </a>
            </div>
        </header>

        <main class="mx-auto max-w-5xl px-4 py-6 sm:px-6">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="mx-auto max-w-5xl px-4 pb-8 sm:px-6">
            <p class="border-t border-slate-200 pt-5 text-center text-xs text-slate-400">
                © <?php echo e(date('Y')); ?> <?php echo e(\App\Http\Controllers\TransparencyController::TRUST_NAME); ?> · Transparency · Service · Accountability
            </p>
        </footer>
    </div>
</div>
</body>
</html>
<?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/layout.blade.php ENDPATH**/ ?>