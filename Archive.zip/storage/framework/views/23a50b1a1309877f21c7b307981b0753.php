
<div class="relative h-52">
    <div class="flex h-full items-end gap-[3px]">
        <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group relative flex h-full flex-1 items-end" title="<?php echo e($s['fy']); ?> · <?php echo e($money($s['value'])); ?>">
                <div class="w-full rounded-t bg-emerald-500/75 transition group-hover:bg-emerald-500"
                     style="height: <?php echo e(max(round($s['value'] / $max * 100, 2), 1)); ?>%"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="pointer-events-none absolute inset-x-0 top-0 flex justify-between text-[10px] text-slate-300">
        <span><?php echo e($money($max)); ?></span>
        <span>0</span>
    </div>
</div>
<div class="mt-2 flex gap-[3px]">
    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex-1 text-center text-[9px] <?php echo e($loop->index % 5 === 0 ? 'text-slate-500' : 'text-transparent'); ?>"><?php echo e($s['label']); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/partials/trend-chart.blade.php ENDPATH**/ ?>