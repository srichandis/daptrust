<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('heading', 'Dashboard'); ?>
<?php $__env->startSection('subheading', 'Trust accounts at a glance'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">INCOME</p>
            <p class="mt-1 text-2xl font-bold text-emerald-600">₹<?php echo e(indian_number_format($incomeTotal, 2)); ?></p>
            <p class="mt-1 text-xs text-slate-400">Donations + Interest + IT Return</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">EXPENSE</p>
            <p class="mt-1 text-2xl font-bold text-red-600">₹<?php echo e(indian_number_format($expenseTotal, 2)); ?></p>
            <p class="mt-1 text-xs text-slate-400">Donations given + Charges</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">SAVINGS</p>
            <p class="mt-1 text-2xl font-bold <?php echo e($savings >= 0 ? 'text-emerald-600' : 'text-red-600'); ?>">
                ₹<?php echo e(indian_number_format($savings, 2)); ?>

            </p>
            <p class="mt-1 text-xs text-slate-400">Income − Expenses</p>
        </div>
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">EXP + SAV</p>
            <p class="mt-1 text-2xl font-bold text-slate-900">₹<?php echo e(indian_number_format($incomeTotal, 2)); ?></p>
            <p class="mt-1 text-xs text-slate-400">Should equal INCOME</p>
        </div>
    </div>

    
    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Account Balances</h2>
        </div>
        <div class="divide-y divide-slate-100">
            <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between px-5 py-3.5">
                    <div class="flex items-center gap-3">
                        <div class="flex h-9 w-9 items-center justify-center rounded-lg text-sm font-bold
                            <?php echo e($account->type === 'cash' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'); ?>">
                            <?php echo e($account->type === 'cash' ? '₹' : substr($account->name, 0, 1)); ?>

                        </div>
                        <div>
                            <p class="font-medium text-slate-900"><?php echo e($account->name); ?></p>
                            <p class="text-xs text-slate-500">
                                <?php echo e(ucfirst($account->type)); ?>

                                <?php if($account->type === 'bank'): ?>
                                    · <?php echo e($account->bank_name ?: '—'); ?> · <?php echo e($account->account_number ?: ''); ?>

                                <?php endif; ?>
                                <?php if($account->investment_type !== 'none'): ?>
                                    · <span class="text-indigo-600"><?php echo e(strtoupper($account->investment_type)); ?> investments</span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <p class="font-semibold <?php echo e($account->balance() < 0 ? 'text-red-600' : 'text-slate-900'); ?>">
                        ₹<?php echo e(indian_number_format($account->balance(), 2)); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="px-5 py-6 text-sm text-slate-500">No accounts yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        
        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Income by Type</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = \App\Models\Entry::GROUPS['Income']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total = $incomeByType[$type] ?? 0; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e(\App\Models\Entry::labelFor($type)); ?></span>
                        <span class="font-semibold text-emerald-600">₹<?php echo e(indian_number_format($total, 2)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-100 px-5 py-4">
                <h2 class="text-lg font-semibold text-slate-900">Expenses by Type</h2>
            </div>
            <div class="divide-y divide-slate-100">
                <?php $__currentLoopData = \App\Models\Entry::GROUPS['Expenses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $total = $expenseByType[$type] ?? 0; ?>
                    <div class="flex items-center justify-between px-5 py-3 text-sm">
                        <span class="text-slate-600"><?php echo e(\App\Models\Entry::labelFor($type)); ?></span>
                        <span class="font-semibold text-red-600">₹<?php echo e(indian_number_format($total, 2)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Trust Summary</h2>
            <p class="mt-1 text-xs text-slate-500">All-time totals across all accounts and financial years</p>
        </div>
        <div class="divide-y divide-slate-100">
            <?php $__currentLoopData = $trustSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isIncome = in_array($label, ['Donor / Receipts', 'Bank Interest', 'FD/RD/MF Interest', 'IT Return']);
                    $isExpense = in_array($label, ['Donation (Disbursements)', 'Bank Charges', 'Professional Charges']);
                    $isNeutral = $label === 'FD + MF + RD (Investments)';
                ?>
                <div class="flex items-center justify-between px-5 py-3 text-sm">
                    <span class="text-slate-600"><?php echo e($label); ?></span>
                    <span class="font-semibold
                        <?php echo e($isIncome ? 'text-emerald-600' : ($isExpense ? 'text-red-600' : 'text-slate-700')); ?>">
                        ₹<?php echo e(indian_number_format($value, 2)); ?>

                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="flex items-center justify-between px-5 py-3 text-sm">
                <span class="text-slate-600">Donation to OPS</span>
                <span class="font-semibold text-red-600">₹<?php echo e(indian_number_format($opsDonationTotal, 2)); ?></span>
            </div>
            <?php
                $netIncome = ($trustSummary['Donor / Receipts'] ?? 0)
                    + ($trustSummary['Bank Interest'] ?? 0)
                    + ($trustSummary['FD/RD/MF Interest'] ?? 0)
                    + ($trustSummary['IT Return'] ?? 0);
                $netExpense = ($trustSummary['Donation (Disbursements)'] ?? 0)
                    + ($trustSummary['Bank Charges'] ?? 0)
                    + ($trustSummary['Professional Charges'] ?? 0);
                $net = $netIncome - $netExpense;
            ?>
            <div class="flex items-center justify-between px-5 py-3.5 text-sm font-semibold">
                <span class="text-slate-800">Net Income − Expenses</span>
                <span class="<?php echo e($net >= 0 ? 'text-emerald-600' : 'text-red-600'); ?>">
                    ₹<?php echo e(indian_number_format($net, 2)); ?>

                </span>
            </div>
        </div>
    </div>

    
    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Latest Entries</h2>
            <a href="<?php echo e(route('admin.entries.index')); ?>" class="text-sm font-medium text-emerald-600 hover:text-emerald-700">View all →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Date</th>
                        <th class="px-5 py-3 font-medium">Type</th>
                        <th class="px-5 py-3 font-medium">Account</th>
                        <th class="px-5 py-3 font-medium">Particulars</th>
                        <th class="px-5 py-3 text-right font-medium">Amount</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $latestEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                            <td class="px-5 py-3">
                                <span class="rounded-full px-2 py-0.5 text-xs font-medium
                                    <?php echo e($entry->is_income ? 'bg-emerald-100 text-emerald-700' : ($entry->is_expense ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600')); ?>">
                                    <?php echo e($entry->label); ?>

                                </span>
                            </td>
                            <td class="px-5 py-3 text-slate-600">
                                <?php echo e($entry->account?->name ?? '—'); ?>

                                <?php if($entry->toAccount): ?> → <?php echo e($entry->toAccount->name); ?> <?php endif; ?>
                            </td>
                            <td class="max-w-xs truncate px-5 py-3 text-slate-500"><?php echo e($entry->particulars ?: $entry->donor_name ?: '—'); ?></td>
                            <td class="px-5 py-3 text-right font-semibold <?php echo e($entry->is_income ? 'text-emerald-600' : ($entry->is_expense ? 'text-red-600' : 'text-slate-700')); ?>">
                                ₹<?php echo e(indian_number_format($entry->amount, 2)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-5 py-6 text-center text-slate-500">No entries yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>