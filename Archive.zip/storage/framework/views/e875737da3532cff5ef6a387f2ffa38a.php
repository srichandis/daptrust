<?php $__env->startSection('title', 'Entries'); ?>
<?php $__env->startSection('heading', 'Entries'); ?>
<?php $__env->startSection('subheading', 'The complete trust ledger'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <p class="text-sm text-slate-500"><?php echo e($entries->total()); ?> entr<?php echo e($entries->total() === 1 ? 'y' : 'ies'); ?> · Filtered total ₹<?php echo e(indian_number_format($totalAmount, 2)); ?></p>
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('admin.entries.create')); ?>"
               class="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700">
                <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/></svg>
                New Entry
            </a>
        </div>
    </div>

    
    <div class="mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <form method="GET" action="<?php echo e(route('admin.entries.index')); ?>" class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-7">
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Entry type</label>
                <select name="entry_type" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="">All types</option>
                    <?php $__currentLoopData = \App\Models\Entry::GROUPS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <optgroup label="<?php echo e($group); ?>">
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php if(($filters['entry_type'] ?? '') === $type): echo 'selected'; endif; ?>><?php echo e(\App\Models\Entry::labelFor($type)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </optgroup>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Account</label>
                <select name="account_id" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="">All accounts</option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>" <?php if(($filters['account_id'] ?? '') == $account->id): echo 'selected'; endif; ?>><?php echo e($account->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Financial year</label>
                <select name="financial_year" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <option value="">All years</option>
                    <?php $__currentLoopData = $financialYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fy); ?>" <?php if(($filters['financial_year'] ?? '') === $fy): echo 'selected'; endif; ?>><?php echo e($fy); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">From</label>
                <input type="date" name="from" value="<?php echo e($filters['from'] ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">To</label>
                <input type="date" name="to" value="<?php echo e($filters['to'] ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
            </div>
            <div>
                <label class="mb-1 block text-xs font-medium text-slate-500">Search</label>
                <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="Donor, receipt, notes…"
                       class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
            </div>
            <div class="flex items-end gap-2">
                <button type="submit" class="rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-900">Filter</button>
                <a href="<?php echo e(route('admin.entries.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Reset</a>
                <a href="<?php echo e(route('admin.entries.export', request()->only(['entry_type', 'account_id', 'financial_year', 'from', 'to']))); ?>"
                   class="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-100">CSV</a>
            </div>
        </form>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                        <th class="px-4 py-3 font-semibold">Date</th>
                        <th class="px-4 py-3 font-semibold">Type</th>
                        <th class="px-4 py-3 font-semibold">Account</th>
                        <th class="px-4 py-3 font-semibold">Particulars / Donor</th>
                        <th class="px-4 py-3 text-right font-semibold">Amount</th>
                        <th class="px-4 py-3 text-right font-semibold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="whitespace-nowrap px-4 py-3 text-slate-500"><?php echo e($entry->entry_date?->format('d M Y')); ?></td>
                            <td class="px-4 py-3">
                                <span class="rounded-full px-2.5 py-0.5 text-xs font-medium
                                    <?php echo e($entry->is_income ? 'bg-emerald-100 text-emerald-700' : ($entry->is_expense ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600')); ?>">
                                    <?php echo e($entry->label); ?>

                                </span>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3 text-slate-600">
                                <?php echo e($entry->account?->name ?? '—'); ?>

                                <?php if($entry->toAccount): ?>
                                    <span class="text-slate-400">→ <?php echo e($entry->toAccount->name); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="max-w-xs px-4 py-3">
                                <?php if($entry->donor_name): ?>
                                    <p class="font-medium text-slate-800"><?php echo e($entry->donor_name); ?></p>
                                    <p class="truncate text-xs text-slate-400"><?php echo e($entry->particulars ?: ''); ?></p>
                                <?php else: ?>
                                    <p class="truncate text-slate-500"><?php echo e($entry->particulars ?: '—'); ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="whitespace-nowrap px-4 py-3 text-right font-semibold <?php echo e($entry->is_income ? 'text-emerald-600' : ($entry->is_expense ? 'text-red-600' : 'text-slate-700')); ?>">
                                ₹<?php echo e(indian_number_format($entry->amount, 2)); ?>

                            </td>
                            <td class="whitespace-nowrap px-4 py-3">
                                <div class="flex items-center justify-end gap-3">
                                    <a href="<?php echo e(route('admin.entries.edit', $entry)); ?>" class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Edit</a>
                                    <form method="POST" action="<?php echo e(route('admin.entries.destroy', $entry)); ?>"
                                          onsubmit="return confirm('Delete this entry? This is the data-correction facility — deletion is permanent.');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="text-sm font-medium text-red-500 hover:text-red-600">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="px-4 py-10 text-center text-slate-500">No entries match your filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="border-t border-slate-100 px-4 py-3">
            <?php echo e($entries->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/entries/index.blade.php ENDPATH**/ ?>