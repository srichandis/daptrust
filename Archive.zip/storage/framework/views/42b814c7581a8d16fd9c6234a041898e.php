<?php $__env->startSection('title', $account->exists ? 'Edit Account' : 'New Account'); ?>
<?php $__env->startSection('heading', $account->exists ? 'Edit Account' : 'New Account'); ?>
<?php $__env->startSection('subheading', $account->exists ? 'Update account details' : 'Add a bank or cash account'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <form method="POST" action="<?php echo e($account->exists ? route('admin.accounts.update', $account) : route('admin.accounts.store')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php if($account->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div class="sm:col-span-2">
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Account name *</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $account->name)); ?>" required
                           placeholder="e.g. HDFC Bank — Main Account"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Type *</label>
                    <select name="type" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <option value="bank" <?php if(old('type', $account->type) === 'bank'): echo 'selected'; endif; ?>>Bank</option>
                        <option value="cash" <?php if(old('type', $account->type) === 'cash'): echo 'selected'; endif; ?>>Cash</option>
                    </select>
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Investment type *</label>
                    <select name="investment_type" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                        <option value="none" <?php if(old('investment_type', $account->investment_type) === 'none'): echo 'selected'; endif; ?>>None</option>
                        <option value="rd" <?php if(old('investment_type', $account->investment_type) === 'rd'): echo 'selected'; endif; ?>>RD</option>
                        <option value="mf" <?php if(old('investment_type', $account->investment_type) === 'mf'): echo 'selected'; endif; ?>>MF</option>
                    </select>
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Bank name</label>
                    <input type="text" name="bank_name" value="<?php echo e(old('bank_name', $account->bank_name)); ?>" placeholder="e.g. State Bank of India"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Branch</label>
                    <input type="text" name="branch" value="<?php echo e(old('branch', $account->branch)); ?>" placeholder="e.g. Jayanagar"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Account number</label>
                    <input type="text" name="account_number" value="<?php echo e(old('account_number', $account->account_number)); ?>"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">IFSC</label>
                    <input type="text" name="ifsc" value="<?php echo e(old('ifsc', $account->ifsc)); ?>" placeholder="e.g. SBIN0001234"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div>
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Opening balance (₹)</label>
                    <input type="number" step="0.01" min="0" name="opening_balance" value="<?php echo e(old('opening_balance', $account->opening_balance ?? 0)); ?>"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>

                <div class="flex items-end">
                    <label class="inline-flex cursor-pointer items-center gap-2.5 text-sm font-medium text-slate-700">
                        <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $account->is_active ?? true)): echo 'checked'; endif; ?>
                               class="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500">
                        Active account
                    </label>
                </div>
            </div>

            <div class="flex items-center gap-3 border-t border-slate-100 pt-5">
                <button type="submit" class="rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700">
                    <?php echo e($account->exists ? 'Save changes' : 'Create account'); ?>

                </button>
                <a href="<?php echo e(route('admin.accounts.index')); ?>" class="text-sm font-medium text-slate-500 hover:text-slate-700">Cancel</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/accounts/form.blade.php ENDPATH**/ ?>