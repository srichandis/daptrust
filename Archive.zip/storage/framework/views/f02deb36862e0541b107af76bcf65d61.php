<?php $__env->startSection('title', $entry->exists ? 'Edit Entry' : 'New Entry'); ?>
<?php $__env->startSection('heading', $entry->exists ? 'Edit Entry' : 'New Entry'); ?>
<?php $__env->startSection('subheading', $entry->exists ? 'Data correction facility — edit or correct this entry' : 'Record a new entry in the trust ledger'); ?>

<?php $__env->startSection('content'); ?>
    <div x-data="entryForm()" class="max-w-4xl">
        <form method="POST" action="<?php echo e($entry->exists ? route('admin.entries.update', $entry) : route('admin.entries.store')); ?>" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php if($entry->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            
            <div class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 class="mb-4 text-lg font-semibold text-slate-900">1 · Entry details</h3>

                <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Entry type *</label>
                        <select name="entry_type" id="entry_type" x-model="type" @change="syncType($el)" required
                                class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <?php $__currentLoopData = \App\Models\Entry::GROUPS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <optgroup label="<?php echo e($group); ?>">
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>" <?php if(old('entry_type', $entry->entry_type) === $type): echo 'selected'; endif; ?>><?php echo e(\App\Models\Entry::labelFor($type)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Date *</label>
                        <input type="date" name="entry_date" value="<?php echo e(old('entry_date', $entry->entry_date?->format('Y-m-d') ?? now()->format('Y-m-d'))); ?>" required
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Amount (₹) *</label>
                        <input type="number" step="0.01" min="0" name="amount" x-model="amount" value="<?php echo e(old('amount', $entry->amount)); ?>" required
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                </div>

                
                <div class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div x-show="type !== 'bank_transfer'">
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Account *</label>
                        <select name="account_id" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <option value="">— Select account —</option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($account->id); ?>" <?php if(old('account_id', $entry->account_id) == $account->id): echo 'selected'; endif; ?>><?php echo e($account->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div x-show="type === 'bank_transfer'" class="grid grid-cols-2 gap-5">
                        <div>
                            <label class="mb-1.5 block text-sm font-medium text-slate-700">From account *</label>
                            <select name="account_id" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                                <option value="">— Select —</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->id); ?>" <?php if(old('account_id', $entry->account_id) == $account->id): echo 'selected'; endif; ?>><?php echo e($account->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <label class="mb-1.5 block text-sm font-medium text-slate-700">To account *</label>
                            <select name="to_account_id" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                                <option value="">— Select —</option>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->id); ?>" <?php if(old('to_account_id', $entry->to_account_id) == $account->id): echo 'selected'; endif; ?>><?php echo e($account->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Particulars / description</label>
                        <input type="text" name="particulars" value="<?php echo e(old('particulars', $entry->particulars)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                </div>

                <div x-show="type === 'fd_investment' || type === 'rd_investment' || type === 'mf_investment' || type === 'fd_maturity' || type === 'rd_maturity' || type === 'mf_maturity'" class="mt-5">
                    <label class="mb-1.5 block text-sm font-medium text-slate-700">Scheme / investment name</label>
                    <input type="text" name="scheme_name" value="<?php echo e(old('scheme_name', $entry->scheme_name)); ?>"
                           placeholder="e.g. SBI RD — 5 year, HDFC MF — ELSS"
                           class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                </div>
            </div>

            
            <div x-show="type === 'donation_income'" class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 class="mb-4 text-lg font-semibold text-slate-900">2 · Donor details</h3>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Donor name</label>
                        <input type="text" name="donor_name" value="<?php echo e(old('donor_name', $entry->donor_name)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">PAN number</label>
                        <input type="text" name="donor_pan" value="<?php echo e(old('donor_pan', $entry->donor_pan)); ?>" placeholder="e.g. ABCDE1234F"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Donor address</label>
                        <textarea name="donor_address" rows="2" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><?php echo e(old('donor_address', $entry->donor_address)); ?></textarea>
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Nature of donation</label>
                        <input type="text" name="nature_of_donation" value="<?php echo e(old('nature_of_donation', $entry->nature_of_donation)); ?>" placeholder="e.g. General / Corpus / Scholarship"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Mode of receipt</label>
                        <select name="mode_of_receipt" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                            <option value="">— Select —</option>
                            <?php $__currentLoopData = ['Cash', 'Cheque', 'Bank transfer', 'UPI', 'Demand draft', 'Online']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mode); ?>" <?php if(old('mode_of_receipt', $entry->mode_of_receipt) === $mode): echo 'selected'; endif; ?>><?php echo e($mode); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Section code (e.g. 80G)</label>
                        <input type="text" name="section_code" value="<?php echo e(old('section_code', $entry->section_code)); ?>" placeholder="e.g. 12A / 80G"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">DAP Trust receipt number</label>
                        <input type="text" name="receipt_number" value="<?php echo e(old('receipt_number', $entry->receipt_number)); ?>" placeholder="e.g. DAP/2026/0001"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Donor bank details</label>
                        <input type="text" name="donor_bank_details" value="<?php echo e(old('donor_bank_details', $entry->donor_bank_details)); ?>"
                               placeholder="Bank, branch, account no. & IFSC (if provided)"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                </div>
            </div>

            
            <div x-show="type === 'donation_expense'" class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 class="mb-4 text-lg font-semibold text-slate-900">2 · Expense allocation</h3>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">To Ops (₹)</label>
                        <input type="number" step="0.01" min="0" name="ops_amount" value="<?php echo e(old('ops_amount', $entry->ops_amount)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">To TSP (₹)</label>
                        <input type="number" step="0.01" min="0" name="tsp_amount" value="<?php echo e(old('tsp_amount', $entry->tsp_amount)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Others (₹)</label>
                        <input type="number" step="0.01" min="0" name="others_amount" value="<?php echo e(old('others_amount', $entry->others_amount)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                </div>
            </div>

            
            <div x-show="type === 'fd_maturity' || type === 'rd_maturity' || type === 'mf_maturity'" class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <h3 class="mb-4 text-lg font-semibold text-slate-900">2 · Maturity details</h3>
                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Interest received (₹)</label>
                        <input type="number" step="0.01" min="0" name="interest_amount" value="<?php echo e(old('interest_amount', $entry->interest_amount)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                    <div>
                        <label class="mb-1.5 block text-sm font-medium text-slate-700">Bank charges (₹)</label>
                        <input type="number" step="0.01" min="0" name="bank_charges_amount" value="<?php echo e(old('bank_charges_amount', $entry->bank_charges_amount)); ?>"
                               class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30">
                    </div>
                </div>
                <p class="mt-3 text-xs text-slate-400">Enter the maturity principal in the Amount field above; interest and charges here are recorded separately for reporting.</p>
            </div>

            
            <div class="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                <label class="mb-1.5 block text-sm font-medium text-slate-700">Notes</label>
                <textarea name="notes" rows="2" class="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"><?php echo e(old('notes', $entry->notes)); ?></textarea>
            </div>

            <div class="flex items-center gap-3">
                <button type="submit" class="rounded-lg bg-emerald-600 px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700">
                    <?php echo e($entry->exists ? 'Save corrections' : 'Record entry'); ?>

                </button>
                <a href="<?php echo e(route('admin.entries.index')); ?>" class="text-sm font-medium text-slate-500 hover:text-slate-700">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function entryForm() {
            return {
                type: <?php echo json_encode(old('entry_type', $entry->entry_type ?? 'donation_income'), 512) ?>,
                amount: <?php echo json_encode(old('amount', $entry->amount ?? ''), 512) ?>,
                syncType(el) {
                    // keep x-model in sync (select options may be set by server-side old())
                    this.type = el.value;
                },
            };
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/entries/form.blade.php ENDPATH**/ ?>