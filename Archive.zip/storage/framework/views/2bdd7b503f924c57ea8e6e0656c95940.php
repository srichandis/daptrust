<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('heading', 'Reports'); ?>
<?php $__env->startSection('subheading', 'All trust reports for a selected period'); ?>

<?php
    $today = now();
    $fyStart = $today->month >= 4 ? $today->copy()->startOfYear()->addMonths(3) : $today->copy()->subYear()->startOfYear()->addMonths(3);
    $fyEnd = $fyStart->copy()->addYear()->subDay();
    $lastFyStart = $fyStart->copy()->subYear();
    $lastFyEnd = $fyEnd->copy()->subYear();
?>

<?php $__env->startSection('content'); ?>
    <style>
        @media print {
            aside, header, .no-print { display: none !important; }
            main { padding: 0 !important; }
            .print-card { border: 0 !important; box-shadow: none !important; }
        }
    </style>

    
    <div class="no-print mb-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="grid gap-4 md:grid-cols-12">
            <div class="md:col-span-3">
                <label class="mb-1 block text-xs font-medium text-slate-500">Report</label>
                <select name="report" onchange="this.form.submit()"
                        class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if($report === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="md:col-span-2">
                <label class="mb-1 block text-xs font-medium text-slate-500">From</label>
                <input type="date" name="from" value="<?php echo e($from); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
            </div>

            <div class="md:col-span-2">
                <label class="mb-1 block text-xs font-medium text-slate-500">To</label>
                <input type="date" name="to" value="<?php echo e($to); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none">
            </div>

            <div class="flex items-end gap-2 md:col-span-5">
                <button type="submit" class="rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-900">Apply period</button>
                <a href="<?php echo e(route('admin.reports.index', ['report' => $report])); ?>"
                   class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">All time</a>
                <span class="mx-1 hidden h-8 w-px bg-slate-200 sm:block"></span>
                <a href="<?php echo e(route('admin.reports.index', ['report' => $report, 'from' => $fyStart->toDateString(), 'to' => $fyEnd->toDateString()])); ?>"
                   class="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-100">This FY</a>
                <a href="<?php echo e(route('admin.reports.index', ['report' => $report, 'from' => $lastFyStart->toDateString(), 'to' => $lastFyEnd->toDateString()])); ?>"
                   class="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-100">Last FY</a>
                <button type="button" onclick="window.print()"
                        class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Print</button>
            </div>
        </form>

        <p class="mt-3 text-xs text-slate-400">
            Period: <?php echo e($from ? \Carbon\Carbon::parse($from)->format('d M Y') : 'Beginning'); ?> —
            <?php echo e($to ? \Carbon\Carbon::parse($to)->format('d M Y') : 'Latest entry'); ?>

        </p>
    </div>

    
    <div class="print-card rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div class="mb-5 flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
                <h2 class="text-lg font-semibold text-slate-900"><?php echo e($reports[$report]); ?></h2>
                <p class="text-xs text-slate-500">
                    <?php echo e($from ? \Carbon\Carbon::parse($from)->format('d M Y') : 'Beginning'); ?> to
                    <?php echo e($to ? \Carbon\Carbon::parse($to)->format('d M Y') : 'Latest entry'); ?>

                </p>
            </div>
        </div>

        <?php switch($report):
            case ('master'): ?>
                <?php echo $__env->make('admin.reports.partials.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('snapshot'): ?>
                <?php echo $__env->make('admin.reports.partials.snapshot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('it-returns'): ?>
                <?php echo $__env->make('admin.reports.partials.it-returns', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('fd-details'): ?>
                <?php echo $__env->make('admin.reports.partials.investments', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('rd-details'): ?>
                <?php echo $__env->make('admin.reports.partials.investments', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('mf-details'): ?>
                <?php echo $__env->make('admin.reports.partials.investments', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('donors'): ?>
                <?php echo $__env->make('admin.reports.partials.donors', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('income'): ?>
                <?php echo $__env->make('admin.reports.partials.specific', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('expense'): ?>
                <?php echo $__env->make('admin.reports.partials.specific', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('statement'): ?>
                <?php echo $__env->make('admin.reports.partials.statement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('accounts'): ?>
                <?php echo $__env->make('admin.reports.partials.accounts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('year-end'): ?>
                <?php echo $__env->make('admin.reports.partials.year-end', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('fd-maturity'): ?>
                <?php echo $__env->make('admin.reports.partials.maturity', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('rd-maturity'): ?>
                <?php echo $__env->make('admin.reports.partials.maturity', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('snapshot-income'): ?>
                <?php echo $__env->make('admin.reports.partials.breakdown', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('snapshot-expense'): ?>
                <?php echo $__env->make('admin.reports.partials.breakdown', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('donation-expense'): ?>
                <?php echo $__env->make('admin.reports.partials.donation-expense', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
            <?php case ('distribution'): ?>
                <?php echo $__env->make('admin.reports.partials.distribution', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>
        <?php endswitch; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>