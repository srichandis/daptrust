
<div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
    <p class="text-sm font-medium text-slate-500"><?php echo e($label); ?></p>
    <p class="mt-1 text-2xl font-bold <?php echo e($color ?? 'text-slate-900'); ?>"><?php echo e($value); ?></p>
    <?php if(isset($hint)): ?>
        <p class="mt-1 text-xs text-slate-400"><?php echo e($hint); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/partials/stat-card.blade.php ENDPATH**/ ?>