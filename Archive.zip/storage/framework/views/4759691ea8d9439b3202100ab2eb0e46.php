<?php $__env->startSection('title', 'DAP Trust Donation Distribution Details'); ?>
<?php $__env->startSection('heading', 'DAP Trust Donation Distribution Details'); ?>
<?php $__env->startSection('subheading', "Donations · where the trust's donations go"); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Total Distributed', 'value' => $money($donationExpense), 'hint' => 'All donation expenses', 'color' => 'text-red-600'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'OPS Donations', 'value' => $money($opsTotal), 'hint' => 'To OPS Saiva Peravai centres'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('transparency.partials.stat-card', ['label' => 'Distribution Heads', 'value' => number_format($byParticulars->count()), 'hint' => 'Distinct purposes recorded'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <div class="mt-6 rounded-xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <h2 class="text-lg font-semibold text-slate-900">Distribution by Particulars</h2>
            <span class="text-xs font-medium text-emerald-600">● Live</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="border-b border-slate-100 text-xs uppercase tracking-wide text-slate-400">
                        <th class="px-5 py-3 font-medium">Particulars</th>
                        <th class="px-5 py-3 text-right font-medium">Transactions</th>
                        <th class="px-5 py-3 text-right font-medium">Total Distributed</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $byParticulars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-5 py-3 font-medium text-slate-800"><?php echo e($row->particulars); ?></td>
                            <td class="px-5 py-3 text-right text-slate-600"><?php echo e(number_format($row->count)); ?></td>
                            <td class="px-5 py-3 text-right font-semibold text-red-600"><?php echo e($money($row->total)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="px-5 py-6 text-center text-slate-500">No donation distribution recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/srichandskaushik/Documents/source/dap/resources/views/transparency/donation-distribution.blade.php ENDPATH**/ ?>